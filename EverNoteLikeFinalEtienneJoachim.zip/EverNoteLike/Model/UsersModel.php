<?php
/**
 * Created by PhpStorm.
 * User: JOACHIM
 * Date: 11/06/2017
 * Time: 00:21
 */

function getAllUsers() {
    $m = new MongoClient();
    $db = $m->EverNoteLike;
    $coll = $db->Users;
    $cursor = $coll->find();
}

function displayAllUsers()
{
    $m = new MongoClient();
    $db = $m->EverNoteLike;
    $coll = $db->Users;
    $cursor = $coll->find();
    foreach ($cursor as $doc) {
        echo("Bienvenue " . $doc["name"] . " !");
    }

}