INSTALLATION DU PROJET EVERNOTELIKE :

Pr�-requis :
WAMP 32bits(La version 64 bits de wamp ne reconnait pas le driver mongodb pour php)

--Installation DE MongoDB

1. Cr�er le dossier c:\wamp\bin\mongodb\
2. T�l�charger la derni�re version de mongodb : http://www.mongodb.org/downloads
3. Cr�er le dossier c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\      //x.x.x correspondant � la version de mongodb qui a �t� t�l�charg�e
3. Cr�er les dossiers :
	c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\data
	c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\data\db
	c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\logs
	c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\conf
4.Dans c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\conf cr�er un fichier nomm� mongodb.conf
5.Ajouter la configuration suivante au fichier mongodb.conf(En modifiant les chemins si n�cessaire):
	# mongodb.conf

	# data lives here
	dbpath=c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\data\db

	# where to log
	logpath=c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\logs\mongodb.log
	logappend=true

	# only run on localhost for development
	bind_ip = 127.0.0.1                                                             

	port = 27017
	rest = true

6.Executer la commande suivante de fa�on � installer mongod en tant que service Windows(En modifiant les chemins si n�cessaire):
	mongod.exe --install --config c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\conf\mongodb.conf --logpath c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\logs\mongodb.log
7.Executer services.msc et v�rifier que le service MongoDB existe, faire un clic droit dessus et le d�marrer

--Ajout de mongo.exe au path
1. Ajouter le chemin : c:\wamp\bin\mongodb\mongodb-win32-x86_64-x.x.x\bin   � la variable path
2. Ajouter le chemin : c:\wamp\bin\php\php5.x.x   � la variable path //x.x.x correspondant � la version de mongodb qui a �t� t�l�charg�e


--Utiliser mongo.exe pour v�rifier que tout est install� et fonctionne
1.lancer une invite de commande en mode admin
2.executer la commande : mongo
3.executer la commande : use EverNoteLike
4.executer la commande : db.createCollection("Users")
5.executer la commande : db.createCollection("Notes")
6.executer la commande : db.showCollections
7.executer la commande : exit;

--Installation de l'extension mongoDB pour php
1. T�l�charger la version 1.6.8 de l'extension mongodb pour php  : https://s3.amazonaws.com/drivers.mongodb.org/php/index.html   (Utiliser ce lien ! Le driver fournit sur le site mongodb ne fonctionne pas)
2. Extraire le fichier php_mongo-1.6.8-5.6-vc11.dll et le placer dans c:\wamp\bin\php\php-5.x.x\ext\ puis le renommer php_mongo.dll
3. Dans le fichier php.ini, ajouter la ligne : extension=php_mongo.dll juste avant extension=php_mysql.dll
4. Red�marrer les services wamp et v�rifier que php_mongo est bien charg� dans les extensions php de wamp


--Lancement du projet
1.Cr�er le dossier EverNoteLike dans c:\wamp\www\
2.Importer les fichier obtenus sur le git dans ce dossier
3.Acc�der � l'url : http://localhost/EverNoteLike/
4.Cr�er un compte
5. Pour modifier une note il faut cliquer sur Note (num�ro de la note) :


Ps : D�sol� si l'application est moche(et pour les fautes d'orthographe dans le tuto), je n'avais pas de dev front sous la main et le css me fait vomir je ne sais pas pourquoi