<?php
/**
 * Created by PhpStorm.
 * User: JOACHIM
 * Date: 11/06/2017
 * Time: 01:46
 */
include "../Controller/AuthController.php";
session_start();
?>
<html lang="en">
<head>
    <meta charset="utf-8">

    <title>EverNoteLike-Login</title>
    <meta name="description" content="The HTML5 Herald">
    <meta name="author" content="JoachimR">

    <link rel="stylesheet" href="Styles/styles.css?v=1.0">
    <!--[if lt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script>
    <![endif]-->
</head>
<header>
    <h1>EverNoteLike</h1>
    <form  method="post" name="createNote" id="searchform" action="../Controller/NotesController.php">
        <input type="text" name="search" id="search" /><input type="hidden" name="authorSearch" id="authorSearch" value="<?php echo $_SESSION['login']; ?>" /><input type="submit" value="Rechercher" name="searchButton"/>
    </form>
    <a href="Logout.php">Déconnexion</a>
</header>
<body>
<div id="mySidenav" class="sidenav">
    <a href="Notes.php">Profil</a>
    <a href="CreateNote.php">Créer une note</a>
</div>
<div id="main">
    <?php
    $usersNoteQuery = array("NoteAuthor" => $_SESSION['login']);
    $m = new MongoClient();
    $db = $m->EverNoteLike;
    $coll = $db->Notes;
    $cursor = $coll->find($usersNoteQuery);
    $i = 1;
    foreach($cursor as $res){
        echo "<h3 onclick='location.href=\"http://localhost/EverNoteLike/View/EditNotes.php?idnote=".$res["_id"]."\"'>Note ".$i." :</h3></br>";
        echo ("Titre : ".$res["NoteTitle"]."</br> Date d'ajout : ".$res["NoteAddDate"]."</br></br>Hashtags : ".$res["NoteHashtags"]."</br></br>Contenu :</br>".$res["NoteContent"]);
        $i++;
        ?>
        <form  method="post" name="deleteNote" action="../Controller/NotesController.php">
            <input type="hidden" name="id" value="<?= $res["_id"]; ?>" /><input type="submit" name="Delete" value="Supprimmer" />
        </form>
        <?php
        //echo "<button onclick='delete(\"".$res["_id"]."\")'>supprimmer</button>";
    }
    ?>
</div>
<script src="js/scripts.js"></script>
</body>
</html>