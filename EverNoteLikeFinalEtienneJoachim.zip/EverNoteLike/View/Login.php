<?php
/**
 * Created by PhpStorm.
 * User: JOACHIM
 * Date: 11/06/2017
 * Time: 00:30
 */
?>
<html lang="en">
<head>
    <meta charset="utf-8">

    <title>EverNoteLike-Login</title>
    <meta name="description" content="The HTML5 Herald">
    <meta name="author" content="JoachimR">

    <link rel="stylesheet" href="View/Styles/styles.css?v=1.0">
    <!--[if lt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script>
    <![endif]-->
</head>

<body>
<div id="auth">
    <form method="post" action="Controller/AuthController.php">
        <h1>EverNoteLike</h1>
        <br/> You're not logged in as an admin, please do so. <br/><br/>
        <input type="text" name="mail" id="login" /></br>
        <input type="password" name="password" id="pass" /></br>
        <input type="submit" value="Connexion"/>
    </form>
    <a href="View/CreateUser.php">Créer un compte</a>
</div>
<script src="js/scripts.js"></script>
</body>
</html>
