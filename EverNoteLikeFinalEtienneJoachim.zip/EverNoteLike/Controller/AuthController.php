<?php
/**
 * Created by PhpStorm.
 * User: JOACHIM
 * Date: 11/06/2017
 * Time: 01:55
 */
if(isset($_POST['mail'])&& isset($_POST['password'])){
        $postedUsername = $_POST['mail']; //Gets the posted username, put's it into a variable.
        $postedPassword = $_POST['password'];
        $_SESSION['mail'] = $postedUsername;
        $conn = new MongoClient();
        $db = $conn->EverNoteLike;
        $coll = $conn->Users; //Selects the user collection
        $userDatabaseFind = $db->$coll->findOne(array('user_Mail'=> $postedUsername, 'user_Motdepasse'=> $postedPassword));


        if(isset($userDatabaseFind)){
            session_start();
            $_SESSION['login'] = $postedUsername;
            $_SESSION['pwd'] = $postedPassword;
            echo "<script type='text/javascript'>document.location.replace('../View/Notes.php');</script>";


    }else{
            echo "<script type='text/javascript'>document.location.replace('../index.php');</script>";
        }
}