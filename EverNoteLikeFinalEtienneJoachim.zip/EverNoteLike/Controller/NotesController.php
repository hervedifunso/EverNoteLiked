<?php
session_start();

/**
 * Created by PhpStorm.
 * User: JOACHIM
 * Date: 11/06/2017
 * Time: 01:54
 */
 
class NotesController
{
	private $mongo;
	private $database;
	
	public function NotesController(){
		$this->mongo = new MongoClient();
		$this->database = $this->mongo->EverNoteLike;
		switch(true)
		{
			case (isset($_POST["Create"])and $_SERVER['REQUEST_METHOD'] == "POST") :
				$title = $_POST["title"];
				$add_date = $_POST["add_date"];
				$hashtags = $_POST["hashtags"];
				$content = $_POST["content"];
				$author = $_POST["author"];
				$this->createNote($title, $add_date, $hashtags, $content, $author);
				break;
			case (isset($_POST["Edit"])and $_SERVER['REQUEST_METHOD'] == "POST") :
				$id = $_POST["id"];
				$title = $_POST["title"];
				$add_date = $_POST["add_date"];
				$hashtags = $_POST["hashtags"];
				$content = $_POST["content"];
				$author = $_POST["author"];
				$this->editNote($id,$title, $add_date, $hashtags, $content, $author);
				break;
            case (isset($_POST["Delete"])and $_SERVER['REQUEST_METHOD'] == "POST") :
                $id = $_POST["id"];
                $this->deleteNote($id);
                break;
            case (isset($_POST["searchButton"])and $_SERVER['REQUEST_METHOD'] == "POST") :
                $searchQuery = $_POST["search"];
                $searchAuthor = $_POST["authorSearch"];
                $this->searchNote($searchQuery, $searchAuthor);
                break;
		}
	}

	public function createNote($title, $add_date, $hashtags, $content, $author){
		$postedNoteTitle = $title;
		$postedNoteDate = $add_date;
		$postedNoteHashtags = $hashtags;
		$postedNoteContent = $content;
		$postedAuthor = $author;
		$coll = $this->database->Notes;
		$note = array("NoteTitle" => $postedNoteTitle, "NoteAddDate" => $postedNoteDate, "NoteHashtags" => $postedNoteHashtags, "NoteContent" => $postedNoteContent, "NoteAuthor" => $postedAuthor);
		$coll->insert($note);
		echo "<script type='text/javascript'>document.location.replace('../View/Notes.php');</script>";
	}

	public function editNote($id,$title, $add_date, $hashtags, $content, $author){
		$postedNoteTitle = $title;
		$postedNoteDate = $add_date;
		$postedNoteHashtags = $hashtags;
		$postedNoteContent = $content;
		$postedAuthor = $author;
		$coll = $this->database->Notes;
		$note = array("NoteTitle" => $postedNoteTitle, "NoteAddDate" => $postedNoteDate, "NoteHashtags" => $postedNoteHashtags, "NoteContent" => $postedNoteContent, "NoteAuthor" => $postedAuthor);
		$coll->update(array('_id'=>new MongoId($id)),$note);
        echo "<script type='text/javascript'>document.location.replace('../View/Notes.php');</script>";
	}

	public function  deleteNote($idNote){
        $coll = $this->database->Notes;
        $coll->remove(array('_id' => new MongoId($idNote)));
        echo "<script type='text/javascript'>document.location.replace('../View/Notes.php');</script>";
	}

	public function searchNote($search, $author){
        $postedTitleSearch = $search;


        $searchNoteQuery = array("NoteAuthor" => $author, "NoteTitle" => $postedTitleSearch);
        $m = new MongoClient();
        $db = $m->EverNoteLike;
        $coll = $db->Notes;
        $cursor = $coll->find($searchNoteQuery);
        $i = 1;
        foreach($cursor as $res){
            echo "<h3>Résultat ".$i." :</h3></br>";
            echo ("Titre : ".$res["NoteTitle"]."</br> Date d'ajout : ".$res["NoteAddDate"]."</br></br>Hashtags : ".$res["NoteHashtags"]."</br></br>Contenu :</br>".$res["NoteContent"]);
            $i++;
        }
	}
}

$controlleur=new NotesController();