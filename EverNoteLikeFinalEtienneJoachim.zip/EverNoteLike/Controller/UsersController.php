<?php
/**
 * Created by PhpStorm.
 * User: JOACHIM
 * Date: 11/06/2017
 * Time: 01:55
 */

if(isset($_POST["createUser"])and $_SERVER['REQUEST_METHOD'] == "POST"){
    $userMail = $_POST["mail"];
    $userPassword = $_POST["pass"];
    $userName = $_POST["name"];
    createUser($userMail, $userPassword, $userName);
}

function createUser($userMail, $userPassword, $userName){
    $m = new MongoClient();
    $db = $m->EverNoteLike;
    $coll = $db->Users;
    $person = array("user_Mail" => $userMail, "user_Motdepasse" => $userPassword, "user_Nom"=>$userName);
    $coll->insert($person);
    echo "<script type='text/javascript'>document.location.replace('../index.php');</script>";
}

function disconnect(){

}